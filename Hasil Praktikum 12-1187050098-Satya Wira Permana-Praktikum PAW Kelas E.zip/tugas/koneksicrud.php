<?php
$host = 'localhost';
$username = 'root';
$password = '';
$db_name = 'tugas'; // nama databasenya
$conn = new mysqli($host, $username, $password, $db_name);
?>